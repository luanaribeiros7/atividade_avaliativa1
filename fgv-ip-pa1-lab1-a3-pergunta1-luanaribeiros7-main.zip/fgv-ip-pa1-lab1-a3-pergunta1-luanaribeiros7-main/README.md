[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=17051295)
# Exercício 1

Considere que a variável `info` contenha a seguinte lista: `['Curso', 'Python']`. 

Escreva comandos Python que:

(a) Acrescenta a string ‘introdução' na lista armazenada em `info`

(b) Acrescenta a string 'de'

(c) Acrescenta a string 'a'

(d) Mude a ordem dos elementos na lista tal que a lista final seja ['Curso', 'de', 'introdução', 'a', 'Python']
